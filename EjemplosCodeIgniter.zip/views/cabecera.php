
  <!--NAVEGADOR-->
  <header>
  <nav  style="background-color:#70724D;" >
  <div class="container-fluid">
    <div class="navbar-header">
       <h4 class=" color">TENIS</h4>
    </div>
    <ul class="nav navbar-nav">
      <li><a href="<?php echo site_url();?>/tenis">El tenis</a></li>
      <li><a href="<?php echo site_url();?>/tenis/galeria">Galeria</a></li>
      <li><a href="#">Quienes somos</a></li>
      <li><a href="#">Usuario</a></li>
       <li><a href="#">Nuevo usuario</a></li>
    </ul>
  </div>
</nav>
</header>