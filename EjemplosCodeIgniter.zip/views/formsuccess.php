<html>
<head>
<title>My Form</title>
</head>
<body>

<h3>¡Tu formulario fue enviado con éxito!</h3>

<p><?php echo anchor('form', '¡Intentalo de nuevo!'); ?></p>

</body>
</html>