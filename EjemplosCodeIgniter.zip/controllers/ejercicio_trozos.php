<?php 
class ejercicio_trozos extends CI_Controller {
    public function index()  {        	
    	// helpers y libraries
    	$this->load->helper('url');
       	$this->load->view('cabecera_ejercicio');
       	// vista concreta

       	$this->load->view('pie_ejercicio');
    }
    public function historia()  {        	
    	// helpers y libraries
    	$this->load->helper('url');
       	$this->load->view('cabecera_ejercicio');
       	// vista concreta

       	$this->load->view('pie_ejercicio');
    }
    public function galeria()  {        	
    	// helpers y libraries
    	$this->load->helper('url');
       	$this->load->view('cabecera_ejercicio');
       	// vista concreta

       	$this->load->view('pie_ejercicio');
    }
    public function region()  {        	
    	// helpers y libraries
    	$this->load->helper('url');
       	$this->load->view('cabecera_ejercicio');
       	// vista concreta

       	$this->load->view('pie_ejercicio');
    }
    public function usuario()  {        	
    	// helpers y libraries
    	$this->load->helper('url');
       	$this->load->view('cabecera_ejercicio');
       	// vista concreta

       	$this->load->view('pie_ejercicio');
    }

}
?>