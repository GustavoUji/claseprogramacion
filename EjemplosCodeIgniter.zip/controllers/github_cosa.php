<?php 
class github_cosa extends CI_Controller {
    public function index()  {        	
    	// helpers y libraries
    	echo "<h2>Hola a todos.</h2>";
    }
    public function gustavo()  {        	
    	// helpers y libraries
      echo "<h2>Hola a todos. Soy <h1>Gustavo</h1>.</h2>";	
    }
    
    public function alumno() {     	
    	// helpers y libraries
    
    }

}
?>