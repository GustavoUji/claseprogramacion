-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 19-06-2018 a las 14:17:15
-- Versión del servidor: 10.1.28-MariaDB
-- Versión de PHP: 5.6.32

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `test`
--

DELIMITER $$
--
-- Procedimientos
--
CREATE DEFINER=`root`@`localhost` PROCEDURE `doiterate` (`p1` INT)  BEGIN
  label1: LOOP
    SET p1 = p1 + 1;
    IF p1 < 10 THEN ITERATE label1; END IF;
    LEAVE label1;
  END LOOP label1;
END$$

--
-- Funciones
--
CREATE DEFINER=`root`@`localhost` FUNCTION `SimpleCompare` (`n` INT, `m` INT) RETURNS VARCHAR(20) CHARSET latin1 BEGIN
    DECLARE s VARCHAR(20);

    IF n > m THEN SET s = '>';
    ELSEIF n = m THEN SET s = '=';
    ELSE SET s = '<';
    END IF;

    SET s = CONCAT(n, ' ', s, ' ', m);

    RETURN s;
  END$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `cargo`
--

CREATE TABLE `cargo` (
  `categoria` varchar(40) COLLATE latin1_spanish_ci NOT NULL DEFAULT 'Administrativo',
  `sueldo base` decimal(7,2) NOT NULL,
  `ID` bigint(20) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci;

--
-- Volcado de datos para la tabla `cargo`
--

INSERT INTO `cargo` (`categoria`, `sueldo base`, `ID`) VALUES
('Administrativo', '1000.50', 1),
('Peón', '750.75', 2),
('Supervisor', '1867.56', 3),
('Gerente', '3534.90', 4);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `direccion`
--

CREATE TABLE `direccion` (
  `Id` bigint(20) UNSIGNED NOT NULL,
  `Tipo de via` varchar(7) CHARACTER SET latin1 COLLATE latin1_spanish_ci NOT NULL DEFAULT 'Avenida',
  `Nombre` varchar(60) CHARACTER SET latin1 COLLATE latin1_spanish_ci NOT NULL,
  `Número` varchar(4) CHARACTER SET latin1 COLLATE latin1_spanish_ci NOT NULL,
  `CP` varchar(5) CHARACTER SET latin1 COLLATE latin1_spanish_ci NOT NULL,
  `Población` varchar(60) CHARACTER SET latin1 COLLATE latin1_spanish_ci NOT NULL DEFAULT 'Castellón',
  `DNI dueño` char(10) CHARACTER SET latin1 COLLATE latin1_spanish_ci NOT NULL,
  `escalera` varchar(1) CHARACTER SET latin1 COLLATE latin1_spanish_ci DEFAULT NULL,
  `piso` varchar(3) CHARACTER SET latin1 COLLATE latin1_spanish_ci DEFAULT NULL,
  `puerta` varchar(2) CHARACTER SET latin1 COLLATE latin1_spanish_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `direccion`
--

INSERT INTO `direccion` (`Id`, `Tipo de via`, `Nombre`, `Número`, `CP`, `Población`, `DNI dueño`, `escalera`, `piso`, `puerta`) VALUES
(1, 'Calle', 'La Unión', '32', '10000', 'Castellón', '18987555N', NULL, '2', 'C'),
(2, 'Calle', 'La Unión', '23', '12004', 'Castellón', '99999555N', NULL, NULL, NULL),
(3, 'Calle', 'Separación', '1', '12003', 'Castellón', '90789678W', 'B', '12', 'B'),
(4, 'Avenida', 'Rey Don Jaime', '12', '12003', 'Castellón', '45727465N', NULL, '5', 'a'),
(5, 'Avenida', 'Rey Don Jaime', '23', '12001', 'Castellón', '85927465N', NULL, '2', 'A');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `empleados`
--

CREATE TABLE `empleados` (
  `ID` int(10) UNSIGNED NOT NULL,
  `dni` varchar(10) CHARACTER SET latin1 COLLATE latin1_spanish_ci NOT NULL,
  `cargoID` bigint(20) UNSIGNED NOT NULL,
  `fecha_inicio` date NOT NULL,
  `fecha_final` date NOT NULL,
  `comentario` varchar(500) CHARACTER SET latin1 COLLATE latin1_spanish_ci DEFAULT NULL,
  `NUSS` char(13) CHARACTER SET latin1 COLLATE latin1_spanish_ci NOT NULL DEFAULT '1212345678912' COMMENT 'Formato dudoso'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `empleados`
--

INSERT INTO `empleados` (`ID`, `dni`, `cargoID`, `fecha_inicio`, `fecha_final`, `comentario`, `NUSS`) VALUES
(1, '18987555N', 1, '2018-03-01', '2018-03-31', 'Buen chaval.', '1211111111111'),
(2, '99999555N', 2, '2017-01-01', '2018-03-20', NULL, '1222222222222'),
(3, '90789678W', 2, '2017-03-07', '2018-03-29', 'Aún le queda por aprender.', '1233333333333'),
(4, '45727465N', 3, '2016-03-01', '2020-03-31', '¡Guay!', '1212345678912');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `entries`
--

CREATE TABLE `entries` (
  `id` int(11) NOT NULL,
  `title` varchar(40) NOT NULL,
  `content` varchar(80) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `entries`
--

INSERT INTO `entries` (`id`, `title`, `content`) VALUES
(1, 'Hola', 'Me llamo Gustavo. Encantado de conoceros.'),
(2, 'Hi!', 'Yo soy Adolfo. ¿Vienes mucho por así?'),
(3, 'Hola', 'Aquí María. Encantado de conoceros.'),
(4, 'Hi!', 'Yo soy Ramiro. Esto es raro'),
(5, 'Clase del martes', 'No podré ir a veros.'),
(6, 'OK', 'Avisamos al profe.'),
(7, 'Clase del martes', 'Te tomo apuntes?'),
(8, 'OK', 'Avisamos al profe.'),
(9, 'Gracias!', 'Sí, si puedes sería estupendo.'),
(10, 'Apuntes profe', 'Creo que el profe deja las presentaciones en el drive.'),
(11, 'Nuevo', 'Hola, soy nuevo. ¿Por dónde vaís?'),
(12, 'Bienvenido!', 'Por el principio, no te preocupes. ');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `persona`
--

CREATE TABLE `persona` (
  `nombre` varchar(40) COLLATE latin1_spanish_ci NOT NULL,
  `dni` varchar(10) COLLATE latin1_spanish_ci NOT NULL,
  `fecha_nacimiento` date DEFAULT NULL,
  `telefono` varchar(13) COLLATE latin1_spanish_ci DEFAULT NULL,
  `email` varchar(30) COLLATE latin1_spanish_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci;

--
-- Volcado de datos para la tabla `persona`
--

INSERT INTO `persona` (`nombre`, `dni`, `fecha_nacimiento`, `telefono`, `email`) VALUES
('Juan Perez', '12345678Q', '1953-05-09', '666666666', 'g@gmail.com'),
('Gustavo Casañ', '18987455N', '1973-05-17', NULL, NULL),
('Adolfo Casañ', '18987555N', '1973-05-07', NULL, NULL),
('Juanito Suarez', '21345678Q', '1963-06-09', NULL, NULL),
('Gustav Casany', '44557455N', '1993-05-12', '964112233', NULL),
('Cathy Casany', '45727465N', '1995-08-18', NULL, NULL),
('Jesús Ferrandis', '66627465N', '2002-07-17', NULL, NULL),
('Ester Casañ', '85927465N', '1993-08-17', NULL, NULL),
('Ester Ferran', '88827465N', '1982-08-17', NULL, NULL),
('Adolfo Martín', '90789678W', '1968-03-15', NULL, 'ad@gmail.com'),
('Adolfo Martinez', '99999555N', '1993-05-07', NULL, NULL);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `productos`
--

CREATE TABLE `productos` (
  `ID` int(11) NOT NULL,
  `nombre` varchar(40) CHARACTER SET latin1 COLLATE latin1_spanish_ci NOT NULL,
  `precio` decimal(6,2) NOT NULL,
  `tipo` varchar(20) CHARACTER SET latin1 COLLATE latin1_spanish_ci NOT NULL,
  `fabricante` varchar(60) CHARACTER SET latin1 COLLATE latin1_spanish_ci NOT NULL,
  `descripcion` varchar(500) CHARACTER SET latin1 COLLATE latin1_spanish_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `productos`
--

INSERT INTO `productos` (`ID`, `nombre`, `precio`, `tipo`, `fabricante`, `descripcion`) VALUES
(1, 'Rebuenas', '2.00', 'Alimentación', 'Hacendado', 'Galletas de chocolate'),
(2, 'Aqua Deus 0,5', '0.55', 'Bebidas', 'Aquadeus SL', 'Botella de agua mineral 0,5L'),
(3, 'Aqua Deus 1,5', '1.15', 'Bebidas', 'Aquadeus SL', 'Botella de agua mineral 1,5L');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `ventas`
--

CREATE TABLE `ventas` (
  `ID` int(11) NOT NULL,
  `personaID` varchar(10) CHARACTER SET latin1 COLLATE latin1_spanish_ci NOT NULL,
  `productoID` int(11) NOT NULL,
  `fecha` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `IVA` decimal(4,2) NOT NULL DEFAULT '21.00',
  `descuento` decimal(4,2) NOT NULL DEFAULT '0.00',
  `cantidad` int(3) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `ventas`
--

INSERT INTO `ventas` (`ID`, `personaID`, `productoID`, `fecha`, `IVA`, `descuento`, `cantidad`) VALUES
(1, '18987455N', 2, '2018-03-22 17:20:19', '21.00', '0.00', 1),
(2, '18987455N', 3, '2018-03-22 17:21:07', '21.00', '0.00', 2),
(3, '45727465N', 1, '2018-03-22 17:23:12', '11.00', '0.00', 10);

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `cargo`
--
ALTER TABLE `cargo`
  ADD PRIMARY KEY (`ID`);

--
-- Indices de la tabla `direccion`
--
ALTER TABLE `direccion`
  ADD PRIMARY KEY (`Id`),
  ADD UNIQUE KEY `Id` (`Id`),
  ADD KEY `Pertenece` (`DNI dueño`);

--
-- Indices de la tabla `empleados`
--
ALTER TABLE `empleados`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `dni` (`dni`),
  ADD KEY `sueldoID` (`cargoID`);

--
-- Indices de la tabla `entries`
--
ALTER TABLE `entries`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `persona`
--
ALTER TABLE `persona`
  ADD PRIMARY KEY (`dni`);

--
-- Indices de la tabla `productos`
--
ALTER TABLE `productos`
  ADD PRIMARY KEY (`ID`);

--
-- Indices de la tabla `ventas`
--
ALTER TABLE `ventas`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `productoID` (`productoID`),
  ADD KEY `personaID` (`personaID`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `cargo`
--
ALTER TABLE `cargo`
  MODIFY `ID` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT de la tabla `direccion`
--
ALTER TABLE `direccion`
  MODIFY `Id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT de la tabla `empleados`
--
ALTER TABLE `empleados`
  MODIFY `ID` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT de la tabla `entries`
--
ALTER TABLE `entries`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT de la tabla `productos`
--
ALTER TABLE `productos`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT de la tabla `ventas`
--
ALTER TABLE `ventas`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `direccion`
--
ALTER TABLE `direccion`
  ADD CONSTRAINT `Pertenece` FOREIGN KEY (`DNI dueño`) REFERENCES `persona` (`dni`);

--
-- Filtros para la tabla `empleados`
--
ALTER TABLE `empleados`
  ADD CONSTRAINT `empleados_ibfk_1` FOREIGN KEY (`dni`) REFERENCES `persona` (`dni`),
  ADD CONSTRAINT `empleados_ibfk_2` FOREIGN KEY (`cargoID`) REFERENCES `cargo` (`ID`);

--
-- Filtros para la tabla `ventas`
--
ALTER TABLE `ventas`
  ADD CONSTRAINT `ventas_ibfk_1` FOREIGN KEY (`productoID`) REFERENCES `productos` (`ID`),
  ADD CONSTRAINT `ventas_ibfk_2` FOREIGN KEY (`personaID`) REFERENCES `persona` (`dni`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
